// ========================
// AI ENGINE - Client-side content parsing & processing
// ========================
import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import type { Task, CalendarEvent, Subject, SubTask, AIInsight, FocusSession } from '../types';
import { SUBJECT_COLORS } from '../types';

pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.worker.min.mjs';

// ---- PDF Text Extraction ----
export async function extractPDFText(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let fullText = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const strings = (content.items as any[])
      .filter((item: any) => 'str' in item)
      .map((item: any) => item.str);
    fullText += strings.join(' ') + '\n';
  }
  return fullText;
}

// ---- OCR via Tesseract ----
export async function extractImageText(file: File): Promise<string> {
  const { data: { text } } = await Tesseract.recognize(file, 'eng', {
    logger: () => {},
  });
  return text;
}

// ---- Unified text extraction ----
export async function extractFileText(file: File): Promise<string> {
  if (file.type === 'application/pdf') return extractPDFText(file);
  if (file.type.startsWith('image/')) return extractImageText(file);
  return await file.text();
}

// ========================
// AI PARSING ENGINE
// ========================
const SUBJECT_KEYWORDS: Record<string, string[]> = {
  'Mathematics': ['calculus', 'algebra', 'geometry', 'trigonometry', 'math', 'mathematics', 'statistics', 'differential', 'integral', 'linear algebra'],
  'Computer Science': ['programming', 'python', 'java', 'javascript', 'algorithm', 'data structure', 'software', 'coding', 'web development', 'computer science', 'cs'],
  'Physics': ['physics', 'mechanics', 'thermodynamics', 'quantum', 'electromagnetism', 'optics'],
  'Biology': ['biology', 'cell', 'genetics', 'anatomy', 'ecology', 'evolution', 'biochemistry', 'molecular'],
  'Chemistry': ['chemistry', 'organic', 'inorganic', 'reaction', 'compound', 'molecule'],
  'English': ['english', 'literature', 'essay', 'writing', 'grammar', 'composition', 'reading', 'novel'],
  'History': ['history', 'historical', 'ancient', 'medieval', 'civilization'],
  'Economics': ['economics', 'macro', 'micro', 'finance', 'market', 'supply', 'demand'],
  'Psychology': ['psychology', 'behavior', 'cognitive', 'social psych', 'mental', 'neuroscience'],
  'Art': ['art', 'painting', 'sculpture', 'design', 'creative', 'visual'],
  'Music': ['music', 'instrument', 'orchestra', 'chorus', 'harmony'],
  'Philosophy': ['philosophy', 'ethics', 'logic', 'metaphysics', 'epistemology'],
  'Engineering': ['engineering', 'mechanical', 'electrical', 'civil', 'structural'],
  'Law': ['law', 'legal', 'constitutional', 'statute', 'tort', 'contract'],
  'Political Science': ['political science', 'politics', 'government', 'policy', 'diplomacy'],
};

const DEADLINE_KEYWORDS = [
  'due', 'deadline', 'submit', 'submission', 'assignment', 'project',
  'essay', 'paper', 'report', 'homework', 'exam', 'test', 'quiz',
  'presentation', 'midterm', 'final',
];

const DATE_PATTERNS = [
  /\b\d{4}-\d{2}-\d{2}\b/g,
  /\b\d{1,2}\/\d{1,2}\/\d{4}\b/g,
  /\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+\d{1,2}\b/gi,
  /\b(next|this)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|week|month)\b/gi,
  /\b(tomorrow|today)\b/gi,
];

function resolveRelativeDate(text: string): Date | null {
  const lower = text.toLowerCase();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (lower.includes('today')) return today;
  if (lower.includes('tomorrow')) {
    const t = new Date(today); t.setDate(today.getDate() + 1); return t;
  }
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  if (lower.includes('next')) {
    for (const day of days) {
      if (lower.includes(day)) {
        const targetIdx = days.indexOf(day);
        const currentIdx = today.getDay();
        let diff = targetIdx - currentIdx;
        if (diff <= 0) diff += 7;
        const next = new Date(today);
        next.setDate(today.getDate() + diff);
        return next;
      }
    }
  }
  return null;
}

function resolveDateString(dateStr: string): Date | null {
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    const d = new Date(dateStr + 'T00:00:00');
    return isNaN(d.getTime()) ? null : d;
  }
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateStr)) {
    const d = new Date(dateStr + 'T00:00:00');
    return isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(dateStr + ', ' + new Date().getFullYear() + 'T00:00:00');
  return isNaN(d.getTime()) ? null : d;
}

function findDatesInText(text: string): Date[] {
  const dates: Date[] = [];
  const seen = new Set<string>();
  for (const pattern of DATE_PATTERNS) {
    const matches = text.match(pattern);
    if (matches) {
      for (const match of matches) {
        const key = match.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        const resolved = resolveRelativeDate(match);
        if (resolved) dates.push(resolved);
        else { const date = resolveDateString(match); if (date) dates.push(date); }
      }
    }
  }
  return dates;
}

function detectSubjects(text: string): string[] {
  const detected: string[] = [];
  const lower = text.toLowerCase();
  for (const [subject, keywords] of Object.entries(SUBJECT_KEYWORDS)) {
    for (const kw of keywords) {
      if (lower.includes(kw)) {
        if (!detected.includes(subject)) detected.push(subject);
        break;
      }
    }
  }
  return detected;
}

function detectTaskType(text: string): Task['type'] {
  const l = text.toLowerCase();
  if (l.includes('exam') || l.includes('test') || l.includes('midterm') || l.includes('final')) return 'Exam Revision';
  if (l.includes('read') || l.includes('chapter') || l.includes('article') || l.includes('novel')) return 'Reading';
  if (l.includes('project')) return 'Project';
  if (l.includes('homework') || l.includes('assignment') || l.includes('problem set') || l.includes('pset')) return 'Homework';
  return 'Assignment';
}

function detectPriority(text: string): Task['priority'] {
  const l = text.toLowerCase();
  if (l.includes('urgent') || l.includes('important') || l.includes('critical') || l.includes('asap')) return 'High';
  if (l.includes('easy') || l.includes('optional') || l.includes('extra credit')) return 'Low';
  return 'Medium';
}

function estimateHours(text: string): number {
  const l = text.toLowerCase();
  if (l.includes('research paper') || l.includes('thesis')) return 8;
  if (l.includes('essay') || l.includes('paper')) return 4;
  if (l.includes('project') || l.includes('presentation')) return 4;
  if (l.includes('exam') || l.includes('midterm') || l.includes('final')) return 6;
  if (l.includes('problem set') || l.includes('pset') || l.includes('homework')) return 2;
  if (l.includes('read') || l.includes('chapter')) return 1.5;
  if (l.includes('quiz')) return 1;
  return 2;
}

function splitIntoSubtasks(text: string): SubTask[] {
  const lines = text.split(/[.;\n]+/).filter(l => l.trim().length > 10 && l.trim().length < 120);
  return lines.slice(0, 6).map((l, i) => ({
    id: `sub-${Date.now()}-${i}`,
    title: l.trim().replace(/\s+/g, ' ').substring(0, 100),
    completed: false,
  }));
}

export interface ParsedResult {
  tasks: Omit<Task, 'id'>[];
  subjects: Omit<Subject, 'id'>[];
  summary: string;
}

export function parseContent(text: string, existingSubjects: Subject[]): ParsedResult {
  const tasks: Omit<Task, 'id'>[] = [];
  const subjects: Omit<Subject, 'id'>[] = [];
  const dates = findDatesInText(text);
  const detectedSubjects = detectSubjects(text);

  const existingNames = existingSubjects.map(s => s.name.toLowerCase());
  for (const sub of detectedSubjects) {
    if (!existingNames.includes(sub.toLowerCase())) {
      subjects.push({
        name: sub,
        color: SUBJECT_COLORS[subjects.length % SUBJECT_COLORS.length],
        difficulty: 'Medium',
      });
    }
  }

  const segments = text.split(/\n{2,}/).filter(s => s.trim().length > 8);
  for (const segment of segments) {
    const segLower = segment.toLowerCase();
    const hasDeadline = DEADLINE_KEYWORDS.some(kw => segLower.includes(kw));
    const segmentDates = findDatesInText(segment);

    if (hasDeadline || segmentDates.length > 0) {
      const titleLines = segment.split(/\n/).filter(l => l.trim().length > 3);
      let title = titleLines[0]?.trim().substring(0, 120) || segment.trim().substring(0, 120);
      title = title.replace(/^(due|deadline|submit|assignment)[:\-\s]+/i, '').trim();
      if (!title) continue;

      const deadlineDate = segmentDates.length > 0 ? segmentDates[0] :
        (dates.length > 0 ? dates[0] : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000));

      tasks.push({
        title,
        subjectId: '',
        deadline: deadlineDate.toISOString().split('T')[0],
        type: detectTaskType(segment),
        priority: detectPriority(segment),
        completed: false,
        subtasks: splitIntoSubtasks(segment),
        estimatedHours: estimateHours(segment),
        createdAt: new Date().toISOString(),
        source: 'ai',
      });
    }
  }

  if (tasks.length === 0 && detectedSubjects.length > 0) {
    for (const sub of detectedSubjects) {
      const defaultDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
      tasks.push({
        title: `${sub} — Track assignments & exams`,
        subjectId: '',
        deadline: defaultDate.toISOString().split('T')[0],
        type: 'Other',
        priority: 'Medium',
        completed: false,
        subtasks: [],
        estimatedHours: 2,
        createdAt: new Date().toISOString(),
        source: 'ai',
      });
    }
  }

  const summary = text.length > 500
    ? `Extracted ${tasks.length} task${tasks.length !== 1 ? 's' : ''} from your document.${dates.length > 0 ? ` Found ${dates.length} deadline${dates.length !== 1 ? 's' : ''}.` : ''} ${detectedSubjects.length > 0 ? `Identified subjects: ${detectedSubjects.join(', ')}.` : ''}`
    : `Found ${tasks.length} actionable item${tasks.length !== 1 ? 's' : ''}.${detectedSubjects.length > 0 ? ` Related to ${detectedSubjects.join(', ')}.` : ''}`;

  return { tasks, subjects, summary };
}

// ========================
// STUDY PLAN GENERATOR
// ========================
export function generateStudyPlan(tasks: Task[], studyPreference: string): CalendarEvent[] {
  const events: CalendarEvent[] = [];
  const incomplete = tasks.filter(t => !t.completed);
  incomplete.sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  let studyHour = 17;
  if (studyPreference === 'Morning') studyHour = 9;
  else if (studyPreference === 'Afternoon') studyHour = 14;
  else if (studyPreference === 'Night') studyHour = 20;

  for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
    const day = new Date(today);
    day.setDate(day.getDate() + dayOffset);
    const dayStr = day.toISOString().split('T')[0];

    const dueToday = incomplete.filter(t => t.deadline === dayStr);
    const upcoming = incomplete.filter(t => {
      const d = new Date(t.deadline);
      const diff = Math.ceil((d.getTime() - day.getTime()) / (1000 * 60 * 60 * 24));
      return diff > 0 && diff <= 3;
    });

    const tasksForDay = [...dueToday, ...upcoming.slice(0, 2)];
    let hour = studyHour;
    for (const task of tasksForDay) {
      const start = new Date(day);
      start.setHours(hour, 0, 0, 0);
      const end = new Date(start);
      end.setHours(start.getHours() + Math.max(1, Math.ceil(task.estimatedHours)), 0, 0, 0);
      events.push({
        id: `plan-${task.id}-${dayOffset}`,
        title: `Study: ${task.title.substring(0, 40)}`,
        type: 'Study',
        startTime: start.toISOString(),
        endTime: end.toISOString(),
        subjectId: task.subjectId,
      });
      hour += Math.max(1, Math.ceil(task.estimatedHours)) + 1;
    }

    if (tasksForDay.length > 0) {
      const bs = new Date(day); bs.setHours(hour, 0, 0, 0);
      const be = new Date(bs); be.setHours(bs.getHours() + 1, 0, 0, 0);
      events.push({
        id: `brk-${dayOffset}`,
        title: 'Break', type: 'Break',
        startTime: bs.toISOString(), endTime: be.toISOString(),
      });
    }
  }
  return events;
}

// ========================
// AI COACHING INSIGHTS
// ========================
export function generateInsights(tasks: Task[], focusSessions: FocusSession[]): AIInsight[] {
  const insights: AIInsight[] = [];
  const incomplete = tasks.filter(t => !t.completed);
  const highPriority = incomplete.filter(t => t.priority === 'High');
  const now = new Date();

  const overdue = incomplete.filter(t => new Date(t.deadline) < now);
  if (overdue.length > 0) {
    insights.push({
      id: `ins-${Date.now()}-1`, title: `${overdue.length} Overdue Task${overdue.length > 1 ? 's' : ''}`,
      description: `You have ${overdue.length} overdue item${overdue.length > 1 ? 's' : ''}. Let's reschedule these.`,
      type: 'warning', createdAt: new Date().toISOString(),
    });
  }

  if (highPriority.length >= 3) {
    insights.push({
      id: `ins-${Date.now()}-2`, title: 'Heavy Workload Ahead',
      description: `${highPriority.length} high-priority items detected. Focus on closest deadline first.`,
      type: 'warning', createdAt: new Date().toISOString(),
    });
  }

  const soonDue = incomplete.filter(t => {
    const d = new Date(t.deadline);
    const diff = Math.ceil((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff > 0 && diff <= 2;
  });
  if (soonDue.length > 0 && overdue.length === 0) {
    const task = soonDue[0];
    insights.push({
      id: `ins-${Date.now()}-3`, title: `Upcoming: ${task.title.substring(0, 30)}`,
      description: `Due in ${Math.ceil((new Date(task.deadline).getTime() - now.getTime()) / (1000 * 60 * 60 * 24))} day(s). Start now.`,
      type: 'schedule', createdAt: new Date().toISOString(),
    });
  }

  if (focusSessions.length >= 3) {
    insights.push({
      id: `ins-${Date.now()}-4`, title: 'Great Consistency!',
      description: `${focusSessions.length} focus sessions completed. Keep building momentum.`,
      type: 'congrats', createdAt: new Date().toISOString(),
    });
  }

  insights.push({
    id: `ins-${Date.now()}-5`, title: 'Spaced Repetition Reminder',
    description: 'Review at increasing intervals boosts retention. Schedule a quick 10-min review for your oldest subject.',
    type: 'tip', createdAt: new Date().toISOString(),
  });

  insights.push({
    id: `ins-${Date.now()}-6`, title: 'Optimal Study Window',
    description: 'Most students perform best in 45-90 min focused blocks with 10-min breaks. Match your sessions to your energy rhythm.',
    type: 'coaching', createdAt: new Date().toISOString(),
  });

  return insights;
}
