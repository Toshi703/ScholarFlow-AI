import { useState, useEffect, useRef } from 'react';
import {
  LayoutDashboard, Sparkles, CheckSquare, Calendar as CalIcon,
  Timer, BarChart3, UserCircle, Send, Upload,
  Plus, Trash, ChevronDown, ChevronUp, Check,
  Play, Pause, RefreshCw, Star,
  ArrowRight, Lightbulb, AlertTriangle, Clock,
  ChevronLeft, ChevronRight, Menu, BookOpen, Target
} from 'lucide-react';
import {
  UserProfile, Subject, Task, CalendarEvent, FocusSession,
  AIInsight, TaskType, EMPTY_PROFILE
} from './types';
import {
  extractFileText, parseContent, generateStudyPlan, generateInsights
} from './utils/aiEngine';

// App logo image — used everywhere as the brand mark
const Logo = ({ size = 32, rounded = true }: { size?: number; rounded?: boolean }) => (
  <img
    src="/logo.png"
    alt="ScholarFlow AI"
    draggable={false}
    className={rounded ? 'rounded-xl' : ''}
    style={{ width: size, height: size, objectFit: 'cover', flexShrink: 0, display: 'block' }}
  />
);

const LS = {
  get: <T,>(key: string, fallback: T): T => {
    try { const d = localStorage.getItem('sf_' + key); return d ? JSON.parse(d) : fallback; }
    catch { return fallback; }
  },
  set: <T,>(key: string, val: T) => localStorage.setItem('sf_' + key, JSON.stringify(val)),
};

export default function App() {
  const [tab, setTab] = useState('dashboard');
  const [mobileMenu, setMobileMenu] = useState(false);

  const [profile, setProfile] = useState<UserProfile>(() => LS.get('profile', EMPTY_PROFILE));
  const [subjects, setSubjects] = useState<Subject[]>(() => LS.get('subjects', []));
  const [tasks, setTasks] = useState<Task[]>(() => LS.get('tasks', []));
  const [events, setEvents] = useState<CalendarEvent[]>(() => LS.get('events', []));
  const [insights, setInsights] = useState<AIInsight[]>(() => LS.get('insights', []));
  const [focusSessions, setFocusSessions] = useState<FocusSession[]>(() => LS.get('focusSessions', []));
  const [showOnboarding, setShowOnboarding] = useState(() => !LS.get('profile', EMPTY_PROFILE).isOnboarded);

  useEffect(() => { LS.set('profile', profile); }, [profile]);
  useEffect(() => { LS.set('subjects', subjects); }, [subjects]);
  useEffect(() => { LS.set('tasks', tasks); }, [tasks]);
  useEffect(() => { LS.set('events', events); }, [events]);
  useEffect(() => { LS.set('insights', insights); }, [insights]);
  useEffect(() => { LS.set('focusSessions', focusSessions); }, [focusSessions]);
  useEffect(() => {
    if (tasks.length > 0 || focusSessions.length > 0) setInsights(generateInsights(tasks, focusSessions));
  }, [tasks, focusSessions]);

  const getSubjectColor = (subId: string) => subjects.find((s: Subject) => s.id === subId)?.color || '#64748b';
  const getSubjectName = (subId: string) => subjects.find((s: Subject) => s.id === subId)?.name || 'General';

  const addTask = (t: Task) => setTasks(prev => [t, ...prev]);
  const deleteTask = (id: string) => setTasks(prev => prev.filter((t: Task) => t.id !== id));
  const toggleTask = (id: string) => setTasks(prev => prev.map((t: Task) => t.id === id ? { ...t, completed: !t.completed } : t));
  const toggleSubtask = (taskId: string, subId: string) => setTasks(prev => prev.map((t: Task) => {
    if (t.id !== taskId) return t;
    return { ...t, subtasks: t.subtasks.map((s) => s.id === subId ? { ...s, completed: !s.completed } : s) };
  }));
  const addSubject = (s: Omit<Subject, 'id'>) => {
    const ns: Subject = { ...s, id: `sub-${Date.now()}` };
    setSubjects(prev => [...prev, ns]);
    return ns;
  };
  const addEvent = (e: CalendarEvent) => setEvents(prev => [...prev, e]);
  const completeFocusSession = (subjectId: string, minutes: number, type: FocusSession['type']) => {
    setFocusSessions(prev => [...prev, { durationMinutes: minutes, type, date: new Date().toISOString().split('T')[0], subjectId, id: `fs-${Date.now()}` }]);
  };
  const recomputeSchedule = () => {
    const plan = generateStudyPlan(tasks, profile.studyPreference);
    const existing = events.filter((e: CalendarEvent) => !e.id.startsWith('plan-') && !e.id.startsWith('brk-'));
    setEvents([...existing, ...plan]);
  };

  if (showOnboarding) {
    return <Onboarding
      profile={profile}
      onUpdateProfile={setProfile}
      onComplete={() => {
        setProfile(p => ({ ...p, isOnboarded: true, onboardedAt: new Date().toISOString() }));
        setShowOnboarding(false);
      }}
    />;
  }

  return (
    <div className="min-h-screen bg-[#fafafa] font-sans text-[#1a1a2e]">
      {mobileMenu && <div className="fixed inset-0 bg-black/30 z-40 md:hidden backdrop-blur-sm" onClick={() => setMobileMenu(false)} />}
      <Sidebar tab={tab} setTab={(t: string) => { setTab(t); setMobileMenu(false); }} tasks={tasks} mobileMenu={mobileMenu} />
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-white z-30 flex items-center px-4 border-b border-gray-100">
        <button onClick={() => setMobileMenu(!mobileMenu)} className="p-2 hover:bg-gray-100 rounded-lg transition mr-2">
          <Menu className="w-5 h-5 text-gray-600" />
        </button>
        <Logo size={28} />
        <span className="text-sm font-bold text-[#1a1a2e] ml-2">ScholarFlow <span className="text-[#4f8bf5] font-medium">AI</span></span>
      </div>
      <main className="md:ml-[260px] pt-14 md:pt-0">
        <div className="px-4 py-6 md:px-10 md:py-8 lg:px-14 lg:py-10 max-w-[1100px] mx-auto">
          {tab === 'dashboard' && <DashboardPage profile={profile} tasks={tasks} events={events} subjects={subjects} insights={insights} focusSessions={focusSessions} onTab={setTab} onToggleTask={toggleTask} getSubjectColor={getSubjectColor} getSubjectName={getSubjectName} />}
          {tab === 'ai' && <AIAssistantPage subjects={subjects} onAddTask={addTask} onAddSubject={addSubject} onGeneratePlan={recomputeSchedule} />}
          {tab === 'tasks' && <TasksPage tasks={tasks} subjects={subjects} onAddTask={addTask} onDeleteTask={deleteTask} onToggleTask={toggleTask} onToggleSubtask={toggleSubtask} getSubjectName={getSubjectName} />}
          {tab === 'calendar' && <CalendarPage events={events} subjects={subjects} onAddEvent={addEvent} onGeneratePlan={recomputeSchedule} getSubjectColor={getSubjectColor} />}
          {tab === 'focus' && <FocusPage subjects={subjects} defaultWork={profile.pomodoroWork} defaultBreak={profile.pomodoroBreak} onComplete={completeFocusSession} />}
          {tab === 'stats' && <StatsPage tasks={tasks} subjects={subjects} focusSessions={focusSessions} />}
          {tab === 'profile' && <ProfilePage profile={profile} setProfile={setProfile} />}
        </div>
      </main>
    </div>
  );
}

/* ═══════════════════════════════════════
   SIDEBAR — ChatGPT-style clean nav
   ═══════════════════════════════════════ */
function Sidebar({ tab, setTab, tasks, mobileMenu }: { tab: string; setTab: (t: string) => void; tasks: Task[]; mobileMenu: boolean }) {
  const navItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'ai', name: 'AI Assistant', icon: Sparkles },
    { id: 'tasks', name: 'Tasks', icon: CheckSquare },
    { id: 'calendar', name: 'Calendar', icon: CalIcon },
    { id: 'focus', name: 'Focus Mode', icon: Timer },
    { id: 'stats', name: 'Analytics', icon: BarChart3 },
  ];

  const incomplete = tasks.filter((t: Task) => !t.completed);
  const high = incomplete.filter((t: Task) => t.priority === 'High').length;
  let loadPct = 25;
  let loadColor = 'bg-emerald-500';
  if (high >= 3 || incomplete.length >= 7) { loadPct = 100; loadColor = 'bg-red-500'; }
  else if (high >= 2 || incomplete.length >= 5) { loadPct = 75; loadColor = 'bg-orange-500'; }
  else if (high >= 1 || incomplete.length >= 3) { loadPct = 50; loadColor = 'bg-amber-500'; }

  return (
    <aside className={`fixed top-0 left-0 h-full bg-[#f7f7f8] border-r border-gray-200/80 z-50 flex flex-col transition-transform duration-300 ease-out
      ${mobileMenu ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 w-[260px]`}
    >
      {/* Brand */}
      <div className="flex items-center gap-2.5 px-5 pt-5 pb-4 border-b border-gray-200/60">
        <Logo size={32} />
        <div className="leading-tight">
          <span className="block text-[13px] font-bold text-[#1a1a2e] tracking-tight">ScholarFlow</span>
          <span className="block text-[9px] font-semibold tracking-[0.2em] text-gray-400 uppercase">AI</span>
        </div>
      </div>

      {/* Nav items — clean, spacious */}
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {navItems.map(item => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button key={item.id} onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[14px] font-medium transition-all duration-150
                ${active ? 'bg-gray-200/80 text-[#1a1a2e] font-semibold' : 'text-gray-500 hover:bg-gray-100 hover:text-gray-800'}`}
            >
              <Icon className="w-[18px] h-[18px] flex-shrink-0 opacity-70" />
              <span className="truncate">{item.name}</span>
              {item.id === 'tasks' && incomplete.length > 0 && (
                <span className="ml-auto text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-gray-300/70 text-gray-600">{incomplete.length}</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer — minimal */}
      <div className="px-3 py-3 border-t border-gray-200/60">
        <button onClick={() => setTab('profile')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[14px] font-medium transition-all duration-150
          ${tab === 'profile' ? 'bg-gray-200/80 text-[#1a1a2e] font-semibold' : 'text-gray-500 hover:bg-gray-100 hover:text-gray-800'}`}>
          <UserCircle className="w-[18px] h-[18px] flex-shrink-0 opacity-70" />
          <span className="truncate">Profile</span>
        </button>
        <div className="mt-3 px-3">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Mental Load</span>
            <span className="text-[10px] font-bold text-gray-500">{loadPct === 100 ? 'Critical' : loadPct === 75 ? 'High' : loadPct === 50 ? 'Moderate' : 'Low'}</span>
          </div>
          <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-700 ${loadColor}`} style={{ width: `${loadPct}%` }} />
          </div>
        </div>
      </div>
    </aside>
  );
}

/* ═══════════════════════════════════════
   ONBOARDING — clean, no logo image
   ═══════════════════════════════════════ */
function Onboarding({ profile, onUpdateProfile, onComplete }: { profile: UserProfile; onUpdateProfile: (p: UserProfile) => void; onComplete: () => void }) {
  return (
    <div className="min-h-screen bg-[#fafafa] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <Logo size={48} />
          </div>
          <h1 className="text-2xl font-bold text-[#1a1a2e] tracking-tight">Welcome to ScholarFlow <span className="text-[#4f8bf5]">AI</span></h1>
          <p className="text-gray-500 mt-2 text-sm">Your intelligent academic companion</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 space-y-4 shadow-sm">
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Your Name</label>
            <input type="text" value={profile.name} onChange={e => onUpdateProfile({ ...profile, name: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/20 focus:border-[#1a1a2e]/30 transition" placeholder="e.g. Alex Johnson" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">School / University</label>
            <input type="text" value={profile.school} onChange={e => onUpdateProfile({ ...profile, school: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/20 focus:border-[#1a1a2e]/30 transition" placeholder="e.g. Stanford University" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Level</label>
              <select value={profile.academicLevel} onChange={e => onUpdateProfile({ ...profile, academicLevel: e.target.value as any })}
                className="w-full px-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/20 transition">
                <option>High School</option><option>University</option><option>Postgraduate</option><option>Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Best Study Time</label>
              <select value={profile.studyPreference} onChange={e => onUpdateProfile({ ...profile, studyPreference: e.target.value as any })}
                className="w-full px-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/20 transition">
                <option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Evening">Evening</option><option value="Night">Night</option>
              </select>
            </div>
          </div>
          <button onClick={onComplete} disabled={!profile.name.trim() || !profile.school.trim()}
            className="w-full py-3 bg-[#1a1a2e] hover:bg-[#2a2a4e] disabled:bg-gray-200 disabled:text-gray-400 text-white font-semibold rounded-xl transition-all duration-200 text-sm mt-2">
            Get Started →
          </button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   DASHBOARD — clean, spacious, minimal
   ═══════════════════════════════════════ */
function DashboardPage({ profile, tasks, events, subjects, insights, focusSessions, onTab, onToggleTask, getSubjectColor, getSubjectName }: any) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const incomplete = (tasks as Task[]).filter((t: Task) => !t.completed);
  const priorityTasks = incomplete.filter((t: Task) => t.priority === 'High');
  const topTask = priorityTasks[0] || incomplete[0];
  const todayStr = new Date().toISOString().split('T')[0];
  const todayEvents = (events as CalendarEvent[]).filter((e: CalendarEvent) => e.startTime.startsWith(todayStr));
  const totalStudyMin = (focusSessions as FocusSession[]).reduce((s, f) => s + f.durationMinutes, 0);
  const completedCount = (tasks as Task[]).filter((t: Task) => t.completed).length;

  return (
    <div className="space-y-8">
      {/* Greeting */}
      <div>
        <h2 className="text-[28px] font-bold tracking-tight text-[#1a1a2e]">{greeting}, {profile.name?.split(' ')[0] || 'Student'}</h2>
        <p className="text-gray-500 text-sm mt-1">
          {incomplete.length} task{incomplete.length !== 1 ? 's' : ''} remaining · {subjects.length} subject{subjects.length !== 1 ? 's' : ''} tracked
        </p>
      </div>

      {/* Top Action */}
      {topTask ? (
        <div className="bg-[#1a1a2e] text-white rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5"><Target className="w-3 h-3" /> Recommended Action</span>
            <h3 className="text-lg font-bold mt-2">{topTask.title}</h3>
            <p className="text-gray-300 text-sm mt-1">{getSubjectName(topTask.subjectId)} · Due {topTask.deadline} · {topTask.estimatedHours}h estimated</p>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button onClick={() => onTab('focus')} className="px-5 py-2.5 bg-white text-[#1a1a2e] rounded-xl font-semibold text-sm hover:bg-gray-100 transition flex items-center gap-2">
              <Play className="w-3.5 h-3.5" /> Start Focus
            </button>
            <button onClick={() => onToggleTask(topTask.id)} className="px-5 py-2.5 bg-white/10 text-white rounded-xl font-semibold text-sm hover:bg-white/20 transition flex items-center gap-2 border border-white/10">
              <Check className="w-3.5 h-3.5" /> Done
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-2xl p-8 text-center border border-gray-100">
          <BookOpen className="w-8 h-8 text-gray-300 mx-auto mb-2" />
          <p className="text-gray-500 text-sm font-medium">All caught up! Use the AI Assistant to add new assignments.</p>
        </div>
      )}

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Study Time', value: `${Math.floor(totalStudyMin / 60)}h ${totalStudyMin % 60}m`, icon: Clock },
          { label: 'Completed', value: `${completedCount}`, icon: Check },
          { label: 'Focus Sessions', value: `${(focusSessions as FocusSession[]).length}`, icon: Sparkles },
          { label: 'Today', value: `${todayEvents.length} event${todayEvents.length !== 1 ? 's' : ''}`, icon: CalIcon },
        ].map((s, i) => (
          <div key={i} className="bg-white border border-gray-200/70 rounded-2xl p-4 hover:border-gray-300 transition-colors">
            <s.icon className="w-4 h-4 text-gray-400 mb-2" />
            <span className="text-[11px] text-gray-400 font-medium uppercase tracking-wider">{s.label}</span>
            <p className="text-2xl font-bold text-[#1a1a2e] mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Two column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Schedule */}
        <div className="lg:col-span-3 bg-white border border-gray-200/70 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-700">Today's Schedule</h3>
            <button onClick={() => onTab('calendar')} className="text-xs text-gray-400 hover:text-gray-700 transition flex items-center gap-1">Full calendar <ArrowRight className="w-3 h-3" /></button>
          </div>
          {todayEvents.length === 0 ? (
            <div className="py-10 text-center text-sm text-gray-400">No events scheduled for today</div>
          ) : (
            <div className="divide-y divide-gray-50">
              {todayEvents.map((evt: CalendarEvent) => (
                <div key={evt.id} className="px-5 py-3.5 flex items-center gap-3 hover:bg-gray-50/50 transition">
                  <div className="w-2 h-8 rounded-full" style={{ backgroundColor: getSubjectColor(evt.subjectId) }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{evt.title}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      {new Date(evt.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} – {new Date(evt.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full uppercase">{evt.type}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Insights */}
        <div className="lg:col-span-2 bg-white border border-gray-200/70 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2"><Lightbulb className="w-4 h-4 text-amber-500" /> AI Insights</h3>
          </div>
          <div className="p-4 space-y-2.5 max-h-[320px] overflow-y-auto">
            {(insights as AIInsight[]).length === 0 && <p className="text-center text-sm text-gray-400 py-6">Add tasks to get insights</p>}
            {(insights as AIInsight[]).slice(0, 4).map((ins: AIInsight) => (
              <div key={ins.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                <div className="flex items-center gap-1.5 mb-1">
                  {ins.type === 'warning' && <AlertTriangle className="w-3 h-3 text-amber-500" />}
                  {ins.type === 'congrats' && <Star className="w-3 h-3 text-yellow-500" />}
                  {ins.type === 'coaching' && <Sparkles className="w-3 h-3 text-indigo-500" />}
                  {ins.type === 'schedule' && <Clock className="w-3 h-3 text-blue-500" />}
                  {ins.type === 'tip' && <Lightbulb className="w-3 h-3 text-emerald-500" />}
                  <span className="text-xs font-semibold text-gray-700">{ins.title}</span>
                </div>
                <p className="text-[11px] text-gray-500 leading-relaxed">{ins.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Subjects row */}
      {(subjects as Subject[]).length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-500 mb-3">Subjects</h3>
          <div className="flex flex-wrap gap-2">
            {(subjects as Subject[]).map((sub: Subject) => (
              <div key={sub.id} className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200/70 rounded-xl hover:border-gray-300 transition">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sub.color }} />
                <span className="text-xs font-medium text-gray-700">{sub.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════
   AI ASSISTANT — Gemini-style conversation
   ═══════════════════════════════════════ */
function AIAssistantPage({ subjects, onAddTask, onAddSubject }: any) {
  const [messages, setMessages] = useState<{ id: string; role: 'user' | 'ai'; content: string; tasks?: string[] }[]>([]);
  const [input, setInput] = useState('');
  const [processing, setProcessing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [firstMessage, setFirstMessage] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const processText = async (text: string, label: string) => {
    setProcessing(true);
    if (firstMessage) setFirstMessage(false);
    setMessages(prev => [...prev, { id: `u-${Date.now()}`, role: 'user', content: label }]);
    await new Promise(r => setTimeout(r, 1000 + Math.random() * 1000));
    try {
      const result = parseContent(text, subjects);
      const newIds: string[] = [];
      for (const sub of result.subjects) { const ns = onAddSubject(sub); newIds.push(ns.id); }
      const titles: string[] = [];
      for (const t of result.tasks) {
        onAddTask({ ...t, id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, subjectId: newIds[0] || (subjects.length > 0 ? subjects[0].id : '') });
        titles.push(t.title);
      }
      setMessages(prev => [...prev, {
        id: `ai-${Date.now()}`, role: 'ai',
        content: result.summary + (titles.length > 0 ? '\n\nTasks created:\n' + titles.map(t => `• ${t}`).join('\n') : ''),
        tasks: titles,
      }]);
    } catch {
      setMessages(prev => [...prev, { id: `ai-${Date.now()}`, role: 'ai', content: 'Could not process the content. Try a clearer document or type the information manually.' }]);
    }
    setProcessing(false);
    setInput('');
  };

  const handleFile = async (file: File) => {
    setProcessing(true);
    if (firstMessage) setFirstMessage(false);
    setMessages(prev => [...prev, { id: `u-${Date.now()}`, role: 'user', content: `Uploaded: ${file.name}` }]);
    try {
      const text = await extractFileText(file);
      await new Promise(r => setTimeout(r, 800));
      const result = parseContent(text, subjects);
      const newIds: string[] = [];
      for (const sub of result.subjects) { const ns = onAddSubject(sub); newIds.push(ns.id); }
      const titles: string[] = [];
      for (const t of result.tasks) {
        onAddTask({ ...t, id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, subjectId: newIds[0] || (subjects.length > 0 ? subjects[0].id : '') });
        titles.push(t.title);
      }
      setMessages(prev => [...prev, {
        id: `ai-${Date.now()}`, role: 'ai',
        content: `Document analyzed: ${file.name}\n\n${result.summary}${titles.length > 0 ? '\n\nExtracted tasks:\n' + titles.map(t => `• ${t}`).join('\n') : ''}${titles.length === 0 ? '\n\nNo specific tasks found. Try typing assignment details manually.' : ''}`,
        tasks: titles,
      }]);
    } catch {
      setMessages(prev => [...prev, { id: `ai-${Date.now()}`, role: 'ai', content: `Could not read ${file.name}.` }]);
    }
    setProcessing(false);
  };

  const handleDrop = (e: React.DragEvent) => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]); };
  const handleSend = () => { if (!input.trim()) return; const v = input; setInput(''); processText(v, v); };

  // ——— Empty state (Gemini-style welcome) ———
  if (messages.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] px-4">
        {/* Icon centered */}
        <div className="flex justify-center mb-6">
          <Logo size={56} />
        </div>
        <h2 className="text-2xl font-bold text-[#1a1a2e] mb-2">How can I help you today?</h2>
        <p className="text-gray-400 text-sm max-w-md text-center mb-10">Upload a syllabus, describe your assignments, or ask me to create a study plan.</p>

        {/* Suggestion chips */}
        <div className="flex flex-wrap gap-2 justify-center max-w-lg mb-10">
          {[
            { icon: '📄', text: 'Upload my syllabus PDF', action: () => fileRef.current?.click() },
            { icon: '📅', text: 'Create a study plan for this week', action: () => processText('Create a study plan for this week covering all my subjects with balanced revision blocks.', 'Create a study plan for this week') },
            { icon: '📸', text: 'Upload notes from class', action: () => fileRef.current?.click() },
            { icon: '⏰', text: 'I have an exam next Monday', action: () => processText('I have an exam next Monday. Help me prepare a revision schedule.', 'I have an exam next Monday') },
          ].map((chip, i) => (
            <button key={i} onClick={chip.action} className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 border border-gray-200 rounded-full text-sm text-gray-700 transition">
              <span>{chip.icon}</span> {chip.text}
            </button>
          ))}
        </div>

        {/* Upload zone */}
        <input ref={fileRef} type="file" className="hidden" accept=".pdf,image/*,.txt,.doc,.docx" onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); e.target.value = ''; }} />
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer w-full max-w-md transition ${dragOver ? 'border-[#1a1a2e] bg-gray-50' : 'border-gray-200 hover:border-gray-300'}`}
        >
          <Upload className="w-5 h-5 text-gray-300 mx-auto mb-1" />
          <span className="text-xs text-gray-400">Drop a file or click to upload</span>
        </div>

        {/* Input bar */}
        <div className="w-full max-w-2xl mt-8">
          <div className="flex items-center gap-2 bg-gray-100 rounded-full px-5 py-3 border border-gray-200 focus-within:border-gray-400 focus-within:shadow-sm transition">
            <input
              type="text" value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              disabled={processing}
              placeholder="Message Scholar AI..."
              className="flex-1 bg-transparent text-sm focus:outline-none placeholder-gray-400"
            />
            <button onClick={handleSend} disabled={processing || !input.trim()} className="p-1.5 bg-[#1a1a2e] hover:bg-[#2a2a4e] disabled:bg-gray-300 text-white rounded-full transition">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ——— Conversation view (Gemini-style) ———
  return (
    <div className="flex flex-col h-[calc(100vh-100px)] max-w-[780px] mx-auto">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-1 space-y-1 pb-4">
        {messages.map(msg => (
          <div key={msg.id} className={`py-4 ${msg.role === 'ai' ? '' : 'flex justify-end'}`}>
            {msg.role === 'ai' ? (
              <div className="flex gap-4 items-start">
                {/* AI Avatar */}
                <Logo size={32} />
                <div className="max-w-[85%]">
                  <div className="text-[14px] text-gray-700 leading-relaxed">{msg.content}</div>
                  {msg.tasks && msg.tasks.length > 0 && (
                    <div className="mt-3 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-700">
                      <span className="font-bold flex items-center gap-1.5"><Check className="w-3.5 h-3.5" /> Planner Updated</span>
                      {msg.tasks.map((t: string, i: number) => <div key={i} className="mt-0.5 ml-5">• {t}</div>)}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="max-w-[80%] bg-gray-100 rounded-2xl px-4 py-2.5 text-[14px] text-gray-800">
                {msg.content}
              </div>
            )}
          </div>
        ))}

        {/* Typing indicator */}
        {processing && (
          <div className="py-4">
            <div className="flex gap-4 items-start">
              <Logo size={32} />
              <div className="flex items-center gap-1.5 py-2">
                <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" />
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input bar — fixed at bottom */}
      <div className="border-t border-gray-100 pt-3 pb-4">
        <input ref={fileRef} type="file" className="hidden" accept=".pdf,image/*,.txt,.doc,.docx" onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); e.target.value = ''; }} />
        <div className="flex items-center gap-2 bg-gray-100 rounded-full px-5 py-3 border border-gray-200 focus-within:border-gray-400 focus-within:shadow-sm transition">
          <button onClick={() => fileRef.current?.click()} className="p-1 text-gray-400 hover:text-gray-600 transition flex-shrink-0" title="Upload file">
            <Upload className="w-5 h-5" />
          </button>
          <input
            type="text" value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            disabled={processing}
            placeholder="Message Scholar AI..."
            className="flex-1 bg-transparent text-sm focus:outline-none placeholder-gray-400"
          />
          <button onClick={handleSend} disabled={processing || !input.trim()} className="p-1.5 bg-[#1a1a2e] hover:bg-[#2a2a4e] disabled:bg-gray-300 text-white rounded-full transition flex-shrink-0">
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   TASKS PAGE
   ═══════════════════════════════════════ */
function TasksPage({ tasks, subjects, onAddTask, onDeleteTask, onToggleTask, onToggleSubtask, getSubjectName }: any) {
  const [filterPrio, setFilterPrio] = useState('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'done'>('all');
  const [showForm, setShowForm] = useState(false);
  const [expanded, setExpanded] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ title: '', subjectId: (subjects as Subject[])[0]?.id || '', deadline: '', type: 'Homework' as TaskType, priority: 'Medium' as Task['priority'], estHours: 2 });

  const filtered = (tasks as Task[]).filter((t: Task) => {
    if (filterPrio !== 'all' && t.priority !== filterPrio) return false;
    if (filterStatus === 'active' && t.completed) return false;
    if (filterStatus === 'done' && !t.completed) return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    onAddTask({ ...form, id: `task-${Date.now()}`, deadline: form.deadline || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0], completed: false, subtasks: [], estimatedHours: form.estHours, createdAt: new Date().toISOString(), source: 'manual' });
    setForm({ ...form, title: '', deadline: '' });
    setShowForm(false);
  };

  const prioDot = (p: string) => p === 'High' ? 'bg-red-500' : p === 'Medium' ? 'bg-amber-500' : 'bg-emerald-500';

  return (
    <div className="space-y-6 max-w-[700px] mx-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Tasks</h2>
        <button onClick={() => setShowForm(!showForm)} className="inline-flex items-center gap-2 px-4 py-2 bg-[#1a1a2e] text-white rounded-xl font-medium text-sm hover:bg-[#2a2a4e] transition">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {showForm && (
        <form onSubmit={submit} className="bg-white border border-gray-200 rounded-2xl p-5 space-y-3">
          <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/10" placeholder="Task title..." required />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <select value={form.subjectId} onChange={e => setForm({ ...form, subjectId: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none">{(subjects as Subject[]).map((s: Subject) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            <input type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
            <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value as any })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none"><option value="High">High</option><option value="Medium">Medium</option><option value="Low">Low</option></select>
            <input type="number" step="0.5" min="0.5" value={form.estHours} onChange={e => setForm({ ...form, estHours: parseFloat(e.target.value) })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" placeholder="Hours" />
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-gray-500 text-sm rounded-xl hover:bg-gray-50 transition">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-[#1a1a2e] text-white font-medium text-sm rounded-xl hover:bg-[#2a2a4e] transition">Save</button>
          </div>
        </form>
      )}

      {/* Search + Filters */}
      <div className="flex gap-2 items-center">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="flex-1 px-3 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/10" />
        <select value={filterPrio} onChange={e => setFilterPrio(e.target.value)} className="px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs font-medium focus:outline-none"><option value="all">All</option><option value="High">High</option><option value="Medium">Medium</option><option value="Low">Low</option></select>
        <div className="flex bg-white border border-gray-200 rounded-xl overflow-hidden">
          {(['all', 'active', 'done'] as const).map(f => (
            <button key={f} onClick={() => setFilterStatus(f)} className={`px-3 py-2 text-xs font-medium capitalize transition ${filterStatus === f ? 'bg-[#1a1a2e] text-white' : 'text-gray-500 hover:bg-gray-50'}`}>{f}</button>
          ))}
        </div>
      </div>

      {/* Task list */}
      <div className="space-y-1.5">
        {filtered.length === 0 && <div className="text-center py-16 text-gray-400 text-sm">No tasks found</div>}
        {filtered.map((task: Task) => (
          <div key={task.id} className={`bg-white border rounded-2xl overflow-hidden transition-all ${task.completed ? 'border-gray-100 opacity-50' : 'border-gray-200/70 hover:border-gray-300'}`}>
            <div className="px-4 py-3 flex items-center gap-3">
              <button onClick={() => onToggleTask(task.id)} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition ${task.completed ? 'bg-[#1a1a2e] border-[#1a1a2e]' : 'border-gray-300 hover:border-[#1a1a2e]'}`}>
                {task.completed && <Check className="w-3 h-3 text-white" />}
              </button>
              <div className={`w-2 h-2 rounded-full ${prioDot(task.priority)}`} />
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium truncate ${task.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}>{task.title}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{getSubjectName(task.subjectId)} · Due {task.deadline}</p>
              </div>
              <div className="flex items-center gap-1">
                {task.subtasks.length > 0 && (
                  <button onClick={() => setExpanded(p => p.includes(task.id) ? p.filter(x => x !== task.id) : [...p, task.id])} className="p-1 text-gray-400 hover:text-gray-600">
                    {expanded.includes(task.id) ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                )}
                <button onClick={() => onDeleteTask(task.id)} className="p-1.5 text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition"><Trash className="w-3.5 h-3.5" /></button>
              </div>
            </div>
            {expanded.includes(task.id) && task.subtasks.length > 0 && (
              <div className="px-8 pb-3 pt-1 border-t border-gray-50 space-y-1.5">
                {task.subtasks.map((st: any) => (
                  <div key={st.id} className="flex items-center gap-2">
                    <button onClick={() => onToggleSubtask(task.id, st.id)} className={`w-3.5 h-3.5 rounded border flex items-center justify-center flex-shrink-0 ${st.completed ? 'bg-[#1a1a2e] border-[#1a1a2e]' : 'border-gray-300'}`}>
                      {st.completed && <Check className="w-2.5 h-2.5 text-white" />}
                    </button>
                    <span className={`text-xs ${st.completed ? 'line-through text-gray-400' : 'text-gray-600'}`}>{st.title}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   CALENDAR PAGE
   ═══════════════════════════════════════ */
// @ts-ignore
function CalendarPage({ events, subjects, onAddEvent, onGeneratePlan, getSubjectColor: _gc }: any) {
  // Use _gc via getSubjectColor alias for JSX
  const getSubjectColor = (id?: string) => _gc(id);
  const [view, setView] = useState<'week' | 'list'>('week');
  void setView;
  const [curDate, setCurDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', type: 'Study', subjectId: '', date: new Date().toISOString().split('T')[0], start: '09:00', end: '10:00' });

  const weekDays = (() => {
    const day = curDate.getDay();
    const start = new Date(curDate);
    start.setDate(curDate.getDate() - day + (day === 0 ? -6 : 1));
    return Array.from({ length: 7 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
  })();

  const getDayEvents = (date: Date) => { const ds = date.toISOString().split('T')[0]; return (events as CalendarEvent[]).filter((e: CalendarEvent) => e.startTime.startsWith(ds)); };
  const submit = (e: React.FormEvent) => { e.preventDefault(); onAddEvent({ id: `evt-${Date.now()}`, title: form.title, type: form.type, startTime: `${form.date}T${form.start}:00`, endTime: `${form.date}T${form.end}:00`, subjectId: form.subjectId || undefined }); setShowForm(false); setForm({ ...form, title: '' }); };

  return (
    <div className="space-y-5 max-w-[800px] mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-2xl font-bold tracking-tight">Calendar</h2>
        <div className="flex items-center gap-2">
          <button onClick={onGeneratePlan} className="px-3 py-2 text-xs font-medium text-gray-500 bg-gray-100 rounded-xl hover:bg-gray-200 transition">Auto-Plan</button>
          <button onClick={() => setShowForm(!showForm)} className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1a1a2e] text-white font-medium rounded-xl text-sm hover:bg-[#2a2a4e] transition"><Plus className="w-4 h-4" /> Event</button>
        </div>
      </div>

      {showForm && (
        <form onSubmit={submit} className="bg-white border border-gray-200 rounded-2xl p-4 space-y-3">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="col-span-2 md:col-span-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" placeholder="Title" required />
            <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none">{['Class', 'Focus', 'Study', 'Revision', 'Break'].map(t => <option key={t}>{t}</option>)}</select>
            <select value={form.subjectId} onChange={e => setForm({ ...form, subjectId: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none"><option value="">None</option>{(subjects as Subject[]).map((s: Subject) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
            <input type="time" value={form.start} onChange={e => setForm({ ...form, start: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
            <input type="time" value={form.end} onChange={e => setForm({ ...form, end: e.target.value })} className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowForm(false)} className="px-3 py-1.5 text-gray-500 text-sm rounded-xl hover:bg-gray-50 transition">Cancel</button>
            <button type="submit" className="px-3 py-1.5 bg-[#1a1a2e] text-white font-medium text-sm rounded-xl transition">Save</button>
          </div>
        </form>
      )}

      <div className="flex items-center justify-between bg-white border border-gray-200/70 rounded-2xl px-4 py-3">
        <button onClick={() => setCurDate(p => { const d = new Date(p); d.setDate(d.getDate() - 7); return d; })} className="p-1.5 hover:bg-gray-100 rounded-lg transition"><ChevronLeft className="w-4 h-4" /></button>
        <span className="text-sm font-semibold">Week of {weekDays[0].toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</span>
        <button onClick={() => setCurDate(p => { const d = new Date(p); d.setDate(d.getDate() + 7); return d; })} className="p-1.5 hover:bg-gray-100 rounded-lg transition"><ChevronRight className="w-4 h-4" /></button>
      </div>

      {view === 'week' ? (
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map((day, i) => {
            const today = new Date().toISOString().split('T')[0] === day.toISOString().split('T')[0];
            const dayEvts = getDayEvents(day);
            return (
              <div key={i} className={`rounded-2xl border min-h-[220px] flex flex-col ${today ? 'border-[#1a1a2e]/20 bg-gray-50' : 'border-gray-200/50 bg-white'}`}>
                <div className={`p-2 text-center border-b ${today ? 'bg-[#1a1a2e] text-white rounded-t-2xl' : 'border-gray-100 text-gray-600'}`}>
                  <span className="block text-[9px] font-semibold uppercase">{day.toLocaleDateString([], { weekday: 'short' })}</span>
                  <span className="text-base font-bold">{day.getDate()}</span>
                </div>
                <div className="flex-1 p-1.5 space-y-1 overflow-y-auto">
                  {dayEvts.length === 0 && <span className="text-[9px] text-gray-300 text-center block mt-6">—</span>}
                  {dayEvts.map((evt: CalendarEvent) => (
                    <div key={evt.id} className="p-1.5 rounded-lg bg-white border border-gray-100">
                      <span className="text-[8px] text-gray-400 font-semibold uppercase block truncate">{evt.type}</span>
                      <span className="text-[10px] font-medium text-gray-700 truncate block">{evt.title}</span>
                      <span className="text-[8px] text-gray-400">{new Date(evt.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white border border-gray-200/70 rounded-2xl divide-y">
          {(events as CalendarEvent[]).length === 0 ? <p className="text-center py-12 text-gray-400 text-sm">No events scheduled</p> :
            [...events].sort((a: CalendarEvent, b: CalendarEvent) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()).map((evt: CalendarEvent) => (
              <div key={evt.id} className="px-4 py-3 flex items-center gap-3">
                <div className="w-2 h-8 rounded-full" style={{ backgroundColor: getSubjectColor(evt.subjectId) }} />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-800">{evt.title}</p>
                  <p className="text-[11px] text-gray-400">{new Date(evt.startTime).toLocaleDateString()} · {new Date(evt.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
                <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full uppercase">{evt.type}</span>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════
   FOCUS MODE
   ═══════════════════════════════════════ */
function FocusPage({ subjects, defaultWork, defaultBreak, onComplete }: any) {
  const [mode, setMode] = useState<'Quick Focus' | 'Deep Work' | 'Long Revision'>('Deep Work');
  const [subId, setSubId] = useState((subjects as Subject[])[0]?.id || '');
  void setSubId;
  const [mins, setMins] = useState(defaultWork);
  const [secs, setSecs] = useState(0);
  const [running, setRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const initialMins = useRef(defaultWork);

  const getDuration = (m: string) => m === 'Quick Focus' ? 15 : m === 'Deep Work' ? 25 : 45;

  useEffect(() => {
    if (!running) { if (isBreak) { setMins(defaultBreak); setSecs(0); } else { const d = getDuration(mode); setMins(d); setSecs(0); initialMins.current = d; } }
  }, [mode, isBreak, running, defaultBreak]);

  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => {
      if (secs > 0) setSecs(s => s - 1);
      else if (mins > 0) { setMins((m: number) => m - 1); setSecs(59); }
      else {
        setRunning(false); clearInterval(iv);
        if (!isBreak) { onComplete(subId, initialMins.current, mode); setIsBreak(true); setMins(defaultBreak); setSecs(0); }
        else { setIsBreak(false); const d = getDuration(mode); setMins(d); setSecs(0); initialMins.current = d; }
      }
    }, 1000);
    return () => clearInterval(iv);
  }, [running, mins, secs, isBreak, subId, mode, onComplete, defaultBreak]);

  const totalSeconds = mins * 60 + secs;
  const maxSeconds = initialMins.current * 60;
  const progress = maxSeconds > 0 ? (totalSeconds / maxSeconds) * 100 : 100;

  return (
    <div className="max-w-md mx-auto pt-8 space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold tracking-tight">Focus Mode</h2>
        <p className="text-gray-500 text-sm mt-1">Timed study blocks</p>
      </div>

      <div className="flex bg-gray-100 rounded-xl p-1">
        {(['Quick Focus', 'Deep Work', 'Long Revision'] as const).map(m => (
          <button key={m} onClick={() => { setMode(m); if (!running) setIsBreak(false); }} disabled={running}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition disabled:opacity-50 ${mode === m ? 'bg-white text-[#1a1a2e] shadow-sm' : 'text-gray-400'}`}>
            {m === 'Quick Focus' ? '15 min' : m === 'Deep Work' ? '25 min' : '45 min'}
          </button>
        ))}
      </div>

      <div className={`relative rounded-3xl p-12 text-center transition-all ${isBreak ? 'bg-emerald-50' : 'bg-white border border-gray-200'}`}>
        <svg className="w-48 h-48 mx-auto -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="52" fill="none" stroke="#f0f0f0" strokeWidth="6" />
          <circle cx="60" cy="60" r="52" fill="none" stroke={isBreak ? '#10b981' : '#1a1a2e'} strokeWidth="6" strokeDasharray={`${progress * 3.267} 326.7`} strokeLinecap="round" className="transition-all duration-1000" />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-[10px] font-semibold uppercase tracking-wider ${isBreak ? 'text-emerald-500' : 'text-gray-400'}`}>{isBreak ? 'Break' : 'Focusing'}</span>
          <div className="text-5xl font-bold text-[#1a1a2e] tabular-nums mt-1">{String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}</div>
        </div>
      </div>

      <div className="flex justify-center gap-4">
        <button onClick={() => setRunning(!running)} className={`w-14 h-14 rounded-full flex items-center justify-center transition ${running ? 'bg-amber-500 text-white' : 'bg-[#1a1a2e] text-white'}`}>
          {running ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
        </button>
        <button onClick={() => { setRunning(false); setIsBreak(false); const d = getDuration(mode); setMins(d); setSecs(0); initialMins.current = d; }} className="w-14 h-14 rounded-full bg-gray-100 text-gray-500 flex items-center justify-center hover:bg-gray-200 transition">
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   STATS PAGE
   ═══════════════════════════════════════ */
function StatsPage({ tasks, subjects, focusSessions }: any) {
  const totalMin = (focusSessions as FocusSession[]).reduce((s: number, f: FocusSession) => s + f.durationMinutes, 0);
  const done = (tasks as Task[]).filter((t: Task) => t.completed).length;
  const total = (tasks as Task[]).length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  const incomplete = (tasks as Task[]).filter((t: Task) => !t.completed);
  const highP = incomplete.filter((t: Task) => t.priority === 'High').length;

  const sessionsByDate: Record<string, number> = {};
  (focusSessions as FocusSession[]).forEach((f: FocusSession) => { sessionsByDate[f.date] = (sessionsByDate[f.date] || 0) + f.durationMinutes; });
  const last7Days = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); const key = d.toISOString().split('T')[0]; return { label: d.toLocaleDateString([], { weekday: 'short' }), minutes: sessionsByDate[key] || 0 }; });
  const maxMin = Math.max(...last7Days.map(d => d.minutes), 1);

  const subjectStats = (subjects as Subject[]).map((sub: Subject) => {
    const subTasks = (tasks as Task[]).filter((t: Task) => t.subjectId === sub.id);
    const subDone = subTasks.filter((t: Task) => t.completed).length;
    return { ...sub, total: subTasks.length, done: subDone, pct: subTasks.length > 0 ? Math.round((subDone / subTasks.length) * 100) : 0 };
  });

  return (
    <div className="space-y-6 max-w-[700px] mx-auto">
      <h2 className="text-2xl font-bold tracking-tight">Analytics</h2>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Study Time', value: `${Math.floor(totalMin / 60)}h ${totalMin % 60}m` },
          { label: 'Tasks Done', value: `${done}/${total}` },
          { label: 'Completion', value: `${pct}%` },
          { label: 'Urgent', value: `${highP}` },
        ].map((m, i) => (
          <div key={i} className="bg-white border border-gray-200/70 rounded-2xl p-4">
            <span className="text-[11px] text-gray-400 font-medium uppercase tracking-wider">{m.label}</span>
            <p className="text-2xl font-bold text-[#1a1a2e] mt-1">{m.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white border border-gray-200/70 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Last 7 Days</h3>
        <div className="flex items-end gap-2 h-32">
          {last7Days.map((d, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-[10px] text-gray-400">{d.minutes > 0 ? `${d.minutes}m` : ''}</span>
              <div className="w-full bg-gray-100 rounded-t-md relative" style={{ height: '100%' }}>
                <div className="absolute bottom-0 w-full bg-[#1a1a2e] rounded-t-md transition-all duration-700" style={{ height: `${(d.minutes / maxMin) * 100}%` }} />
              </div>
              <span className="text-[10px] font-medium text-gray-400">{d.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white border border-gray-200/70 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">By Subject</h3>
        <div className="space-y-3">
          {subjectStats.map((sub: any) => (
            <div key={sub.id} className="flex items-center gap-3">
              <span className="w-28 text-xs font-medium text-gray-600 truncate">{sub.name}</span>
              <div className="flex-1 bg-gray-100 h-6 rounded-md overflow-hidden relative">
                <div className="h-full rounded-md transition-all duration-700" style={{ width: `${sub.pct}%`, backgroundColor: sub.color, opacity: 0.7 }} />
                <span className="absolute inset-y-0 left-2 flex items-center text-[10px] font-semibold text-white">{sub.done}/{sub.total}</span>
              </div>
              <span className="text-xs font-medium text-gray-400 w-8 text-right">{sub.pct}%</span>
            </div>
          ))}
          {subjectStats.length === 0 && <p className="text-center text-sm text-gray-400 py-4">No subjects yet</p>}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   PROFILE PAGE
   ═══════════════════════════════════════ */
function ProfilePage({ profile, setProfile }: { profile: UserProfile; setProfile: (p: UserProfile) => void }) {
  const update = (field: string, val: any) => setProfile({ ...profile, [field]: val });

  return (
    <div className="max-w-md mx-auto space-y-6 pt-4">
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 bg-[#1a1a2e] rounded-2xl flex items-center justify-center text-white text-xl font-bold">{(profile.name || 'U')[0]}</div>
        <div>
          <h2 className="text-lg font-bold">{profile.name || 'Your Name'}</h2>
          <p className="text-sm text-gray-500">{profile.school || 'Your School'}</p>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-gray-700">Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Name</label>
            <input type="text" value={profile.name} onChange={e => update('name', e.target.value)} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/10" />
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">School</label>
            <input type="text" value={profile.school} onChange={e => update('school', e.target.value)} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1a1a2e]/10" />
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Level</label>
            <select value={profile.academicLevel} onChange={e => update('academicLevel', e.target.value)} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none"><option>High School</option><option>University</option><option>Postgraduate</option><option>Other</option></select>
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Study Time</label>
            <select value={profile.studyPreference} onChange={e => update('studyPreference', e.target.value)} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none"><option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Evening">Evening</option><option value="Night">Night</option></select>
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Focus (min)</label>
            <input type="number" value={profile.pomodoroWork} onChange={e => update('pomodoroWork', parseInt(e.target.value))} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Break (min)</label>
            <input type="number" value={profile.pomodoroBreak} onChange={e => update('pomodoroBreak', parseInt(e.target.value))} className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none" />
          </div>
        </div>
      </div>

      <button onClick={() => { if (confirm('Reset all data?')) { localStorage.clear(); window.location.reload(); } }} className="text-xs text-gray-400 hover:text-red-500 font-semibold transition">Reset All Data</button>
    </div>
  );
}
