// ========================
// TYPES
// ========================
export interface UserProfile {
  name: string;
  email: string;
  academicLevel: 'High School' | 'University' | 'Postgraduate' | 'Other';
  school: string;
  studyPreference: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  timezone: string;
  pomodoroWork: number;
  pomodoroBreak: number;
  isOnboarded: boolean;
  onboardedAt?: string;
}

export interface Subject {
  id: string;
  name: string;
  color: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  notes?: string;
}

export type TaskType = 'Homework' | 'Exam Revision' | 'Reading' | 'Project' | 'Assignment' | 'Other';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  subjectId: string;
  deadline: string;
  type: TaskType;
  priority: 'High' | 'Medium' | 'Low';
  completed: boolean;
  subtasks: SubTask[];
  estimatedHours: number;
  notes?: string;
  createdAt: string;
  source?: 'manual' | 'ai' | 'upload';
}

export interface CalendarEvent {
  id: string;
  title: string;
  type: 'Class' | 'Focus' | 'Study' | 'Revision' | 'Break';
  startTime: string;
  endTime: string;
  subjectId?: string;
  recurring?: boolean;
}

export interface FocusSession {
  id: string;
  durationMinutes: number;
  type: 'Quick Focus' | 'Deep Work' | 'Long Revision';
  date: string;
  subjectId: string;
}

export interface AIInsight {
  id: string;
  title: string;
  description: string;
  type: 'coaching' | 'warning' | 'tip' | 'schedule' | 'congrats';
  createdAt: string;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  content: string;
  uploadedAt: string;
}

// ========================
// CONSTANTS
// ========================
export const SUBJECT_COLORS = [
  '#6366f1', '#8b5cf6', '#06b6d4', '#f59e0b',
  '#10b981', '#ef4444', '#ec4899', '#14b8a6',
  '#f97316', '#84cc16', '#3b82f6', '#a855f7',
];

export const EMPTY_PROFILE: UserProfile = {
  name: '',
  email: '',
  academicLevel: 'University',
  school: '',
  studyPreference: 'Evening',
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  pomodoroWork: 25,
  pomodoroBreak: 5,
  isOnboarded: false,
};
